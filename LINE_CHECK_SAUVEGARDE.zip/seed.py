from models import Base, User, Controle  
from sqlalchemy import create_engine  
from sqlalchemy.orm import sessionmaker  
engine = create_engine("sqlite:///./line_check.db")  
Base.metadata.create_all(bind=engine)  
SessionLocal = sessionmaker(bind=engine)  
db = SessionLocal()  
if db.query(User).count() == 0:  
    db.add(User(id=2, name="Dominique", role="Technicien"))  
    db.add(User(id=3, name="BADINI", role="Technicien"))  
    db.add(User(id=4, name="MATHIEU", role="Technicien"))  
if db.query(Controle).count() == 0:  
    db.add(Controle(id=1, line_name="Portion HTB - Pylone 01", status="En attente"))  
    db.add(Controle(id=2, line_name="Portion HTB - Pylone 02", status="En attente"))  
    db.add(Controle(id=3, line_name="PYLONE 3", status="En attente"))  
    db.add(Controle(id=4, line_name="4", status="En attente"))  
db.commit()  
db.close() 
