from fastapi import FastAPI, Depends, Request, Form, File, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from models import Base, Controle, User
import os

engine = create_engine('sqlite:///./line_check.db', connect_args={'check_same_thread': False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
app = FastAPI()

if not os.path.exists('fichiers_chantier'): 
    os.makedirs('fichiers_chantier')
app.mount('/fichiers', StaticFiles(directory='fichiers_chantier'), name='fichiers')

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def get_pct(status):
    if "OUVERTURES" in status: return 10
    if "PIQUETAGE" in status: return 20
    if "TERRASSEMENT" in status: return 30
    if "FOUILLE" in status: return 40
    if "BETONNAGE" in status: return 50
    if "LIVRAISONS" in status: return 60
    if "ASSEMBLAGE" in status: return 70
    if "REVISION" in status: return 75
    if "VERIFICATION" in status: return 80
    if "POULIE" in status: return 85
    if "DEROULAGE CABLE" in status: return 90
    if "REGLAGE" in status: return 93
    if "PINCE" in status: return 96
    if "ESSAIS" in status: return 100
    return 0

@app.get('/', response_class=HTMLResponse)
def home(db: Session = Depends(get_db)):
    tc = db.query(Controle).count()
    tu = db.query(User).count()
    controles = db.query(Controle).all()
    users = db.query(User).all()
    rows = ''
    for c in controles:
        u = db.query(User).filter(User.id == c.technician_id).first()
        t_name = u.name if u else 'Non assigne'
        d_deb = c.date_debut if c.date_debut else '--'
        d_fin = c.date_fin if c.date_fin else '--'
        mq = c.manquants if c.manquants else 'Aucun'
        pct = get_pct(c.status)
        img = f"<a href='/fichiers/{c.photo_path}' target='_blank'>👁️ Voir Photo</a>" if c.photo_path else 'Pas de photo'
        rows += f"<tr><td style='padding:12px; border-bottom:1px solid #e2e8f0;'>{c.id}</td><td style='padding:12px; border-bottom:1px solid #e2e8f0; font-weight:bold;'>{c.line_name}</td><td style='padding:12px; border-bottom:1px solid #e2e8f0;'><span style='background:#fef3c7;color:#d97706;padding:6px 12px;border-radius:12px;font-size:12px;font-weight:bold;'>{c.status}</span></td><td style='padding:12px; border-bottom:1px solid #e2e8f0;'><div style='background:#e2e8f0;border-radius:8px;width:100px;height:12px;display:inline-block;margin-right:8px;'><div style='background:#16a34a;height:100%;border-radius:8px;width:{pct}%;'></div></div><span style='font-size:12px;font-weight:bold;'>{pct}%</span></td><td style='padding:12px; border-bottom:1px solid #e2e8f0;'>{t_name}</td><td style='padding:12px; border-bottom:1px solid #e2e8f0;'>{d_deb}</td><td style='padding:12px; border-bottom:1px solid #e2e8f0;'>{d_fin}</td><td style='padding:12px; border-bottom:1px solid #e2e8f0; color:#dc2626; font-weight:bold;'>{mq}</td><td style='padding:12px; border-bottom:1px solid #e2e8f0;'>{img}</td></tr>"
    u_list = ''.join([f'<li>ID {usr.id} : {usr.name} ({usr.role})</li>' for usr in users])
    return f"<html><head><title>BUREAU HTB</title><style>body{{font-family:sans-serif; background:#f4f6f9; padding:30px}}header{{background:#0f172a; color:white; padding:20px; border-radius:8px; margin-bottom:20px}}table{{width:100%; border-collapse:collapse; margin-top:15px; background:white; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.05)}}th{{background:#f8fafc; text-align:left; padding:12px; border-bottom:2px solid #e2e8f0; color:#64748b}}ul{{color:#334155}}</style></head><body><header><h1>LINE_CHECK | Console Superviseur (Bureau)</h1></header><div style='background:white; padding:20px; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.05); margin-bottom:20px;'><h2>Tableau de Bord</h2><p>Pylones enregistres: <b>{tc}</b> | Effectif deploye: <b>{tu}</b></p><h3>Equipes au Registre</h3><ul>{u_list}</ul></div><div style='background:white; padding:20px; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.05);'><h2>Suivi Avancement Fin-en-Fin HTB</h2><table><tr><th>ID</th><th>Portion HTB</th><th>Etape Actuelle</th><th>Progression</th><th>Valide Par</th><th>Date Debut</th><th>Date Fin</th><th>Observations / Manquants</th><th>Preuve Visuelle</th></tr>{rows}</table></div></body></html>"

@app.get('/mobile', response_class=HTMLResponse)
def interface_mobile(db: Session = Depends(get_db)):
    controles = db.query(Controle).all()
    users = db.query(User).all()
    opt_pylones = ''.join([f"<option value='{c.id}'>{c.line_name}</option>" for c in controles])
    opt_techs = ''.join([f"<option value='{u.id}'>{u.name}</option>" for u in users])
    return f"<html><head><meta name='viewport' content='width=device-width, initial-scale=1.0'><title>LINE_CHECK Tech</title><style>body{{font-family:sans-serif; background:#f1f5f9; margin:0; padding:15px}}header{{background:#2563eb; color:white; padding:20px; border-radius:12px; margin-bottom:15px; text-align:center}}.form-card{{background:white; padding:20px; border-radius:12px; box-shadow:0 4px 6px rgba(0,0,0,0.05)}}label{{display:block; margin:15px 0 5px 0; font-weight:bold; color:#334155; font-size:14px}}select,input,button{{width:100%; padding:12px; box-sizing:border-box; border-radius:8px; border:1px solid #cbd5e1; font-size:16px; margin-bottom:10px}}button{{background:#10b981; color:white; border:none; font-weight:bold; margin-top:15px; cursor:pointer}}</style></head><body><header><h1 style='margin:0; font-size:20px;'>🛠️ LINE_CHECK Tech</h1><p style='margin:5px 0 0 0; font-size:12px; opacity:0.9;'>Rapport de Terrain HTB</p></header><div class='form-card'><form method='post' action='/maj-statut-mobile' enctype='multipart/form-data'><label>1. Qui etes-vous ?</label><select name='t_id' required><option value='' disabled selected>--- Selectionnez votre Nom ---</option>{opt_techs}</select><label>2. Quel Pylone validez-vous ?</label><select name='c_id' required><option value='' disabled selected>--- Selectionnez le Pylone ---</option>{opt_pylones}</select><label>3. Quelle etape venez-vous de finir ?</label><select name='n_statut' required><option disabled selected value=''>--- Choisir l etape accomplie ---</option><option>1-OUVERTURES DES ACCES</option><option>2-PIQUETAGE</option><option>3- TERRASSEMENT</option><option>4- FOUILLE</option><option>5- BETONNAGE FONDATIONS</option><option>6- LIVRAISONS PYLONES</option><option>7- ASSEMBLAGE ET LEVAGE</option><option>8- REVISION</option><option>9-VERIFICATION MISE A LA TERRE</option><option>9-MIS EN POULIE ET DEROULAGE CABLETTE</option><option>10-DEROULAGE CABLE</option><option>11- REGLAGE ET ANCRAGE</option><option>12- MISE EN PINCE</option><option>12- ESSAIS ET MISE EN SERVICE</option></select><label>Date de Debut :</label><input type='date' name='d_debut'><label>Date de Fin :</label><input type='date' name='d_fin'><label style='color:#dc2626;'>🚨 Liste des Materiels Manquants :</label><input type='text' name='manquants' placeholder='Ex: 4 isolateurs manquants'><label>📸 Preuve Visuelle (Photo Terrain) :</label><input type='file' name='photo' accept='image/*'><button type='submit'>🚀 TRANSMETTRE AU BUREAU</button></form></div></body></html>"

@app.post('/maj-statut-mobile')
def maj_statut_mobile(c_id: int = Form(...), t_id: int = Form(...), n_statut: str = Form(...), d_debut: str = Form(None), d_fin: str = Form(None), manquants: str = Form(None), photo: UploadFile = File(None), db: Session = Depends(get_db)):
    item = db.query(Controle).filter(Controle.id == c_id).first()
    if item:
        item.status = n_statut
        item.technician_id = t_id
        item.date_debut = d_debut
        item.date_fin = d_fin
        item.manquants = manquants
        if photo and photo.filename:
            f_name = f"pylone_{c_id}_{photo.filename}"
            with open(f"fichiers_chantier/{f_name}", "wb") as f: f.write(photo.file.read())
            item.photo_path = f_name
        db.commit()
    return RedirectResponse(url='/mobile', status_code=303)
